"use client";

import { Button } from "@/components/ui/button";
import React from "react";
import { ChevronRight } from "relume-icons";

export function Layout252() {
  return (
    <section className="px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container">
        <div className="mb-12 grid grid-cols-1 items-start gap-5 md:mb-18 md:grid-cols-2 md:gap-x-12 lg:mb-20 lg:gap-x-20">
          <div>
            <h2 className="heading-h3 font-bold">
              Unlock Your Creative Potential with Our Essential Tools and
              Templates
            </h2>
          </div>
          <div>
            <p className="text-medium">
              Get immediate access to a comprehensive suite of basic tools and
              templates designed for real estate marketing. Start creating
              stunning marketing materials for your listings without any design
              skills. Our platform makes it easy to jump right into your first
              project.
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 items-start gap-y-12 md:grid-cols-3 md:gap-x-8 lg:gap-x-12">
          <div className="w-full">
            <div className="mb-6 md:mb-8">
              <img
                src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image-landscape.svg"
                alt="Relume placeholder image"
                className="rounded-image"
              />
            </div>
            <h3 className="heading-h5 mb-3 font-bold md:mb-4">
              Begin Your First Project in Just a Few Clicks
            </h3>
            <p>
              Experience the convenience of instant project initiation with our
              user-friendly interface.
            </p>
            <div className="mt-6 flex items-center gap-4 md:mt-8">
              <Button
                iconRight={<ChevronRight className="text-scheme-text" />}
                variant="link"
                size="link"
              >
                Start
              </Button>
            </div>
          </div>
          <div className="w-full">
            <div className="mb-6 md:mb-8">
              <img
                src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image-landscape.svg"
                alt="Relume placeholder image"
                className="rounded-image"
              />
            </div>
            <h3 className="heading-h5 mb-3 font-bold md:mb-4">
              Easily Upgrade to Professional Plans for Enhanced Features
            </h3>
            <p>
              Seamlessly transition to our professional plans whenever you need
              more advanced tools.
            </p>
            <div className="mt-6 flex items-center gap-4 md:mt-8">
              <Button
                iconRight={<ChevronRight className="text-scheme-text" />}
                variant="link"
                size="link"
              >
                Upgrade
              </Button>
            </div>
          </div>
          <div className="w-full">
            <div className="mb-6 md:mb-8">
              <img
                src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image-landscape.svg"
                alt="Relume placeholder image"
                className="rounded-image"
              />
            </div>
            <h3 className="heading-h5 mb-3 font-bold md:mb-4">
              Access All Features with Our Flexible Subscription Options
            </h3>
            <p>Choose the plan that best fits your needs and start creating.</p>
            <div className="mt-6 flex items-center gap-4 md:mt-8">
              <Button
                iconRight={<ChevronRight className="text-scheme-text" />}
                variant="link"
                size="link"
              >
                Explore
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
