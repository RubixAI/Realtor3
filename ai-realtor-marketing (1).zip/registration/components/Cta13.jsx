"use client";

import { Button } from "@/components/ui/button";
import React from "react";

export function Cta13() {
  return (
    <section className="relative px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container grid grid-rows-1 items-start gap-y-5 md:grid-cols-2 md:gap-x-12 md:gap-y-8 lg:gap-x-20 lg:gap-y-16">
        <div>
          <h1 className="heading-h2 font-bold">
            Complete Your Registration Today
          </h1>
        </div>
        <div>
          <p className="text-medium">
            Don’t miss out on the opportunity to elevate your real estate
            marketing. Finish your registration now and unlock your free trial
            to start creating stunning materials in minutes!
          </p>
          <div className="mt-6 flex flex-wrap gap-4 md:mt-8">
            <Button title="Register">Register</Button>
            <Button title="Cancel" variant="secondary">
              Cancel
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
