import React from "react";
import { Navbar6 } from "./components/Navbar6";
import { Header44 } from "./components/Header44";
import { Contact3 } from "./components/Contact3";
import { Layout90 } from "./components/Layout90";
import { Layout252 } from "./components/Layout252";
import { Layout1 } from "./components/Layout1";
import { Cta13 } from "./components/Cta13";
import { Faq5 } from "./components/Faq5";
import { Footer10 } from "./components/Footer10";

export default function Page() {
  return (
    <div>
      <Navbar6 />
      <Header44 />
      <Contact3 />
      <Layout90 />
      <Layout252 />
      <Layout1 />
      <Cta13 />
      <Faq5 />
      <Footer10 />
    </div>
  );
}
