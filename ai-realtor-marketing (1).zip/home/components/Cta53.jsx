"use client";

import { Button } from "@/components/ui/button";
import { BackgroundCard } from "@/components/ui/card";
import React from "react";

export function Cta53() {
  return (
    <section className="px-[5%] py-16 md:py-24 lg:py-28">
      <BackgroundCard className="relative container">
        <div className="relative z-10 flex flex-col items-center p-8 md:p-12 lg:p-16">
          <div className="max-w-lg text-center">
            <h2 className="heading-h2 mb-5 font-bold text-white md:mb-6">
              Get Started with Your Free Trial
            </h2>
            <p className="text-medium text-white">
              Join now and transform your real estate marketing with our
              powerful AI-driven platform.
            </p>
          </div>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-4 md:mt-8">
            <Button title="Start">Start</Button>
            <Button title="Explore" variant="secondary-alt">
              Explore
            </Button>
          </div>
        </div>
        <div className="absolute inset-0 z-0">
          <img
            src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image.svg"
            className="size-full object-cover"
            alt="Relume placeholder image"
          />
          <div className="absolute inset-0 bg-neutral-darkest/50" />
        </div>
      </BackgroundCard>
    </section>
  );
}
